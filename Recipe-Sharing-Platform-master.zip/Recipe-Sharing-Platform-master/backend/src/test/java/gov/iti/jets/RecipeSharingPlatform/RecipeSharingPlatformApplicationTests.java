package gov.iti.jets.RecipeSharingPlatform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecipeSharingPlatformApplicationTests {

	@Test
	void contextLoads() {
	}

}
