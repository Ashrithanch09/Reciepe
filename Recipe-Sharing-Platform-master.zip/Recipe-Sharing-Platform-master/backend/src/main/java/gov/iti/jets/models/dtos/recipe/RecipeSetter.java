package gov.iti.jets.models.dtos.recipe;

public class RecipeSetter {
}
