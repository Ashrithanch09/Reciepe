package gov.iti.jets;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class RecipeSharingPlatformApplication {

	public static void main(String[] args) {
		SpringApplication.run(RecipeSharingPlatformApplication.class, args);
	}

}
