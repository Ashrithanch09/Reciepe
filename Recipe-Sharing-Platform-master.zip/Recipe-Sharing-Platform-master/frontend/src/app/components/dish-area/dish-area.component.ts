import { Component } from '@angular/core';

@Component({
  selector: 'app-dish-area',
  templateUrl: './dish-area.component.html',
  styleUrls: ['./dish-area.component.css']
})
export class DishAreaComponent {

}
